# bilibot-web
[![GitHub stars](https://img.shields.io/github/stars/Augenblick-tech/bilibot-web)](https://github.com/Augenblick-tech/bilibot-web/stargazers) [![GitHub forks](https://img.shields.io/github/forks/Augenblick-tech/bilibot-web)](https://github.com/Augenblick-tech/bilibot-web/network) [![GitHub release](https://img.shields.io/github/v/release/Augenblick-tech/bilibot-web?include_prereleases)](https://github.com/Augenblick-tech/bilibot-web/releases) [![GitHub license](https://img.shields.io/github/license/Augenblick-tech/bilibot-web)](https://github.com/Augenblick-tech/bilibot-web/blob/master/LICENSE)

Language: [简体中文](https://github.com/Augenblick-tech/bilibot-web/blob/master/README.md) / English

## Introduction
`bili-bot-web` is the web program for [`bilibot`](https://github.com/Augenblick-tech/bilibot) ...more。

## Functional Support
- 待补充

---

## Plan
- [ ] ...more

### How to use
- ...more

---

# Develop
[Develop Instructions](https://github.com/Augenblick-tech/bilibot-web/blob/master/READ_INSTRUCTIONS.md)

## Recommended IDE Setup

[VSCode](https://code.visualstudio.com/) + [Volar](https://marketplace.visualstudio.com/items?itemName=Vue.volar) (and disable Vetur) + [TypeScript Vue Plugin (Volar)](https://marketplace.visualstudio.com/items?itemName=Vue.vscode-typescript-vue-plugin).

Note: Developer using Windows need to pay extra attention to the newline character.
1. Before cloning the project, please turn off git's autocrlf to avoid newline conflicts. The terminal command is: `git config --global core.autocrlf false`.
2. ~~Replace the default newline character of VSCode with `LF` or `\n`. The replacement method is File->Preferences->Settings, search for crlf, and replace the default `auto` of the 'Files: Eol' option with `\n`.~~ Already configured in ./settings.json.

## Type Support for `.vue` Imports in TS

This template should help get you started developing with Vue 3 in Vite.

TypeScript cannot handle type information for `.vue` imports by default, so we replace the `tsc` CLI with `vue-tsc` for type checking. In editors, we need [TypeScript Vue Plugin (Volar)](https://marketplace.visualstudio.com/items?itemName=Vue.vscode-typescript-vue-plugin) to make the TypeScript language service aware of `.vue` types.

If the standalone TypeScript plugin doesn't feel fast enough to you, Volar has also implemented a [Take Over Mode](https://github.com/johnsoncodehk/volar/discussions/471#discussioncomment-1361669) that is more performant. You can enable it by the following steps:

1. Disable the built-in TypeScript Extension
    1) Run `Extensions: Show Built-in Extensions` from VSCode's command palette
    2) Find `TypeScript and JavaScript Language Features`, right click and select `Disable (Workspace)`
2. Reload the VSCode window by running `Developer: Reload Window` from the command palette.

## Customize configuration

See [Vite Configuration Reference](https://vitejs.dev/config/).

--- 

## Project Setup

```sh
yarn
```

### Compile and Hot-Reload for Development

```sh
yarn dev
```

### Type-Check, Compile and Minify for Production

```sh
yarn build
```

### Lint with [ESLint](https://eslint.org/)

```sh
yarn lint
```
