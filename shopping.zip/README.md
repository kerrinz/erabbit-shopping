# erabbit-shopping
基于Vue3 + TypeScript + Less的在线商城，数据来源于 itheima 的 erabbit
