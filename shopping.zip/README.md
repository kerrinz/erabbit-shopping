# bilibot-web
[![GitHub stars](https://img.shields.io/github/stars/Augenblick-tech/bilibot-web)](https://github.com/Augenblick-tech/bilibot-web/stargazers) [![GitHub forks](https://img.shields.io/github/forks/Augenblick-tech/bilibot-web)](https://github.com/Augenblick-tech/bilibot-web/network) [![GitHub release](https://img.shields.io/github/v/release/Augenblick-tech/bilibot-web?include_prereleases)](https://github.com/Augenblick-tech/bilibot-web/releases) [![GitHub license](https://img.shields.io/github/license/Augenblick-tech/bilibot-web)](https://github.com/Augenblick-tech/bilibot-web/blob/master/LICENSE)

Language: 简体中文 / [English](https://github.com/Augenblick-tech/bilibot-web/blob/master/README_EN.md)

## 简介
`bilibot-web`是[`bilibot`](https://github.com/Augenblick-tech/bilibot)的前端项目，目前支持...（待补充）。

## 功能支持
- 待补充

---

## 计划表
- [ ] 扫码登录B号
- [ ] 管理多个B账户

## 使用方式
- 待补充

---
# 开发

详见[开发文档 / 说明书](https://github.com/Augenblick-tech/bilibot-web/blob/master/READ_INSTRUCTIONS.md)

## 推荐IDE配置

[VSCode](https://code.visualstudio.com/) + [Volar](https://marketplace.visualstudio.com/items?itemName=Vue.volar) （请关闭Vetur插件） + [TypeScript Vue Plugin (Volar)](https://marketplace.visualstudio.com/items?itemName=Vue.vscode-typescript-vue-plugin).

注：使用Windows的开发者需要额外注意换行符的规范。
1. 在clone项目之前，请先关闭git的autocrlf以避免换行符冲突，终端命令为：`git config --global core.autocrlf false`。
2. ~~将VSCode的默认文件换行符替换成`LF`即`\n`，方法为File->Preferences->Settings，搜索crlf，将Files: Eol选项默认的`auto`换成`\n`。~~ 已在./settings.json中配置。


## Type Support for `.vue` Imports in TS

This template should help get you started developing with Vue 3 in Vite.

TypeScript cannot handle type information for `.vue` imports by default, so we replace the `tsc` CLI with `vue-tsc` for type checking. In editors, we need [TypeScript Vue Plugin (Volar)](https://marketplace.visualstudio.com/items?itemName=Vue.vscode-typescript-vue-plugin) to make the TypeScript language service aware of `.vue` types.

If the standalone TypeScript plugin doesn't feel fast enough to you, Volar has also implemented a [Take Over Mode](https://github.com/johnsoncodehk/volar/discussions/471#discussioncomment-1361669) that is more performant. You can enable it by the following steps:

1. Disable the built-in TypeScript Extension
    1) Run `Extensions: Show Built-in Extensions` from VSCode's command palette
    2) Find `TypeScript and JavaScript Language Features`, right click and select `Disable (Workspace)`
2. Reload the VSCode window by running `Developer: Reload Window` from the command palette.


## 自定义配置

参阅 [Vite 配置参考](https://vitejs.dev/config/).

---

## 构建项目

### 安装依赖
```sh
yarn
```

### 启动开发环境

```sh
yarn dev
```

### 生成用于生产环境的最小化文件

```sh
yarn build
```

### 代码规范化 [ESLint](https://eslint.org/)

```sh
yarn lint
```
