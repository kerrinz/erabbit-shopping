# 开发文档 / Develop Instructions

## Global variables

- `/.env.development` & `/.env.production`

  | variable         |                                     |
  | ---------------- | ----------------------------------- |
  | VITE_MODE        | Environment mode. **Not used yet.** |
  | VITE_BASE_URL    | The base url of axios.              |
  | VITE_API_VERSION | Api version in request url.         |
  
  
