import type { BiliLoginQrcodeUrlModel, BotListModel } from "@/model/bot-model";
import { request, type ResponseBody } from "@/request/request";

const version = import.meta.env.VITE_API_VERSION;

// 获取bot列表
export const getBotList = (): Promise<ResponseBody<BotListModel>> =>
  request("get", `${version}/web/bot/list`);

// 获取Bili账号登录的二维码链接
export const getBiliLoginQrcodeUrl = (): Promise<
  ResponseBody<BiliLoginQrcodeUrlModel>
> => request("get", `${version}/bili/qrcode/getLoginUrl`);
