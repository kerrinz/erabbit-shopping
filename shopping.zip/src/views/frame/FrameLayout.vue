<template>
  <TheHeader></TheHeader>
  <div class="container">
    <el-container direction="vertical">
      <el-main>
        <RouterView />
      </el-main>
    </el-container>
  </div>
  <TheFooter>Footer</TheFooter>
</template>

<script setup lang="ts">
import TheFooter from "./TheFooter.vue";
import TheHeader from "./TheTopNavHeader.vue";
</script>

<style scoped lang="less">
.container {
  .page-container();
}
</style>
