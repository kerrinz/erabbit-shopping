<template>
  <div class="container">
    <el-footer>Footer</el-footer>
  </div>
</template>

<script setup lang="ts">
// import { ref } from "vue";
</script>

<style scoped lang="less">
.container {
  .page-container();
}
</style>
