<template>
  <div id="banner">
    <ul class="images">
      <li id="banner_image_previous">
        <a href="#"><img @animationend="animatedPrevious" :src="previousSrc" /></a>
      </li>
      <li id="banner_image_current">
        <a href="#"><img @animationend="animatedCurrent" :src="currentSrc" /></a>
      </li>
      <li id="banner_image_next">
        <a href="#"><img @animationend="animatedNext" :src="nextSrc" /></a>
      </li>
    </ul>
    <div class="pagination">
      <ul>
        <li v-for="n in bannerList.length ?? 0" :key="n" :class="{ active: index == n }"></li>
      </ul>
    </div>
    <div class="operate_previous" @click="handleClickPrevoius">
      <el-icon><ArrowLeft /></el-icon>
    </div>
    <div class="operate_next" @click="handleClickNext">
      <el-icon><ArrowRight /></el-icon>
    </div>
  </div>
</template>
<script setup lang="ts">
import { ArrowLeft, ArrowRight } from "@element-plus/icons-vue";
import { ref } from "vue";

interface _Data {
  image: string;
  href: string;
}

const props = withDefaults(
  defineProps<{
    banners: _Data[];
    index: number;
  }>(),
  {
    index: 0,
  }
);

// 标记是否正在执行动画中
let flagAnimating = false;

// 轮播图的src库
const bannerList = ref(props.banners ?? []);

// 轮播图当前页的索引
const index = ref(0);

const previousAnimationName = ref("unset");
const currentAnimationName = ref("unset");
const nextAnimationName = ref("unset");

// 根据索引获取图片链接
const getImageUrl = (index: number): string => {
  console.log(bannerList?.value[index]?.image);
  return bannerList?.value[index]?.image ?? "";
};

const previousSrc = ref(getImageUrl(index.value));
const currentSrc = ref(getImageUrl(index.value));
const nextSrc = ref(getImageUrl(index.value));

const animatedPrevious = () => {
  previousAnimationName.value = "unset";
  previousSrc.value = getImageUrl((bannerList.value.length + index.value - 1) % bannerList.value.length);
  currentSrc.value = getImageUrl(index.value % bannerList.value.length);
  nextSrc.value = getImageUrl((index.value + 1) % bannerList.value.length);
};

const animatedCurrent = () => {
  currentAnimationName.value = "unset";
  flagAnimating = false;
};

const animatedNext = () => {
  nextAnimationName.value = "unset";
  previousSrc.value = getImageUrl((bannerList.value.length + index.value - 1) % bannerList.value.length);
  currentSrc.value = getImageUrl(index.value % bannerList.value.length);
  nextSrc.value = getImageUrl((index.value + 1) % bannerList.value.length);
};

function next() {
  flagAnimating = true;
  currentAnimationName.value = "toLeft";
  nextAnimationName.value = "toLeft";
  // Navgation指示器变化
  //   navigationDom[(index.value + 1) % bannerList.value.length].classList.add("active");
  //   navigationDom[index.value].classList.remove("active");
  index.value = (index.value + 1) % bannerList.value.length;
}

function previous() {
  flagAnimating = true;
  currentAnimationName.value = "toRight";
  previousAnimationName.value = "toRight";
  const previousIndex = (index.value - 1 + bannerList.value.length) % bannerList.value.length;
  // Navgation指示器变化
  //   navigationDom[previousIndex].classList.add("active");
  //   navigationDom[index.value].classList.remove("active");
  index.value = previousIndex;
}

// 定时器的循环执行函数
function intervalFunc() {
  if (!flagAnimating) {
    next();
  }
}

setInterval(intervalFunc, 3000);

// 下一页
const handleClickNext = () => {
  if (!flagAnimating) {
    next();
  }
};
// 上一页
const handleClickPrevoius = () => {
  if (!flagAnimating) {
    previous();
  }
};
</script>
<style scoped lang="less">
#banner {
  width: 100%;
  min-height: 20vh;
  position: relative;
  overflow: hidden;
  user-select: none;
}

#banner > .images {
  position: relative;
}

#banner_image_previous {
  position: absolute;
  width: 100%;
  left: -100%;
  top: 0;
  bottom: 0;
}

#banner_image_previous img,
#banner_image_next img,
#banner_image_current img {
  animation-duration: 1s;
  animation-timing-function: ease-in-out;
}

#banner_image_next {
  position: absolute;
  width: 100%;
  left: 100%;
  top: 0;
  bottom: 0;
}

#banner > .images img {
  width: 100%;
  object-fit: cover;
  margin: 0;
  padding: 0;
  vertical-align: top;
}

#banner .pagination {
  position: absolute;
  bottom: 0;
  left: 0;
  width: 100%;
  text-align: center;
}

#banner .pagination > ul {
  display: inline-block;
  margin-bottom: 8px;
  padding: 0;
}

#banner .pagination > ul > li {
  margin: 0 2px;
  width: 8px;
  height: 8px;
  display: inline-block;
  background: rgba(255, 255, 255, 0.33);
  border: 1px solid #fff;
  border-radius: 5px;
  box-shadow: 0 0 2px #333;
}

#banner .pagination > ul > li.active {
  background-color: #fff;
}
</style>
