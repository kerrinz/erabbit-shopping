<template>
  <!-- 标准图 -->
  <ul class="goods_list">
    <li class="goods">
      <img @mousemove="onMouseMove" @mouseleave="onMouseLeave" :src="props.src" />
      <span
        class="cursor"
        :style="{
          width: `${cursorWidth}px`,
          height: `${cursorHeight}px`,
          left: `${cursorLeft}px`,
          top: `${cursorTop}px`,
        }"
      ></span>
    </li>
    <!-- 放大图 -->
    <div v-show="isShowViewer" class="viewer" :style="{ width: `${viewerWidth}px`, height: `${viewerHeight}px` }">
      <img
        :src="props.src"
        :style="{
          left: `${viewerImgLeft}px`,
          top: `${viewerImgTop}px`,
          width: `${viewerImgWidth * 100}%`,
          height: `${viewerImgHeight * 100}%`,
        }"
      />
    </div>
  </ul>
</template>

<script setup lang="ts">
import { ref } from "vue";

const props = defineProps<{
  // 图片链接
  src: string;
}>();

// 是否显示大图
const isShowViewer = ref(false);
// 游标的长宽
const cursorWidth = 200;
const cursorHeight = cursorWidth;
// 小图长宽
const imgWidth = 350;
const imgHeight = imgWidth;
// viewer 大图长宽
const viewerWidth = 400;
const viewerHeight = viewerWidth;

const cursorLeft = ref(0);
const cursorTop = ref(0);

const viewerImgWidth = imgWidth / cursorWidth;
const viewerImgHeight = imgHeight / cursorHeight;
const viewerImgLeft = ref(0);
const viewerImgTop = ref(0);

const onMouseMove = (e: MouseEvent) => {
  isShowViewer.value = true;
  // cursor游标的处理
  let _cursorLeft = e.offsetX - cursorWidth / 2;
  let _cursorTop = e.offsetY - cursorHeight / 2;
  if (_cursorLeft < 0) {
    _cursorLeft = 0;
  } else if (_cursorLeft > imgWidth - cursorWidth) {
    _cursorLeft = imgWidth - cursorWidth;
  }
  if (_cursorTop < 0) {
    _cursorTop = 0;
  } else if (_cursorTop > imgHeight - cursorHeight) {
    _cursorTop = imgHeight - cursorHeight;
  }
  _cursorTop = _cursorTop > 0 ? _cursorTop : 0;
  cursorLeft.value = _cursorLeft;
  cursorTop.value = _cursorTop;

  // viewer预览框的处理
  const scaleW = imgWidth / cursorWidth; // width缩放倍率
  const scaleH = imgHeight / cursorHeight; // height缩放倍率
  viewerImgLeft.value = (-_cursorLeft / imgWidth) * viewerWidth * scaleW;
  viewerImgTop.value = (-_cursorTop / imgHeight) * viewerHeight * scaleH;
};

// 鼠标移到图片之外
const onMouseLeave = () => {
  isShowViewer.value = false;
};
</script>
<style lang="less" scoped>
/* 预览大图 */
.viewer {
  width: 600px;
  height: 600px;
  margin-left: 5px;
  position: absolute;
  left: 100%;
  top: 50%;
  pointer-events: none;
  border: 1px #6750a4 solid;
  overflow: hidden;
  z-index: 9999;
  transform: translateY(-50%);
}

.viewer img {
  width: 100%;
  height: 100%;
  position: relative;
}

.goods_list {
  font-size: 0;
  vertical-align: middle;
  position: relative;
  display: inline-block;
}

.goods {
  padding: 0;
  font-size: 0;
}

.goods_list > li {
  width: 350px;
  /* margin: 5px; */
  display: inline-block;
  cursor: pointer;
  position: relative;
  border: 1px #6750a4 solid;
}

.goods_list > li img {
  width: 100%;
  vertical-align: middle;
}

.cursor {
  position: absolute;
  display: inline-block;
  visibility: hidden;
  opacity: 0;
  width: 100px;
  height: 100px;
  pointer-events: none;
  background-color: rgba(190, 136, 174, 0.5);
  transition: visibility.15S, opacity.15s;
}

.goods_list > li:hover .cursor {
  visibility: visible;
  opacity: 1;
}
</style>
