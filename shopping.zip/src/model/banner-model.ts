export interface BannerModel {
  hrefUrl: string;
  id: string;
  imgUrl: string;
  type: string;
}
