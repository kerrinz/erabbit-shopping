/** 加载状态 */
export enum LoadingState {
  loading,
  success,
  failed,
}
