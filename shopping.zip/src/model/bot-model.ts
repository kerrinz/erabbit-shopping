export interface BotListModel {
  id: string | number;
}

export interface BiliLoginQrcodeUrlModel {
  qrcode_key: string | number;
  ts: string | number;
  url: string;
}
