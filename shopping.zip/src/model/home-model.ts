/** 人气推荐 */
export interface RecommendItem {
  alt: string;
  id: string;
  picture: string;
  title: string;
}
