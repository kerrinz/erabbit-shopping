// 通用的商品模型
export interface CommonGoods {
  id: string;
  name: string;
  desc: string;
  orderNum: number;
  picture: string;
  price: string;
  discount: number;
}
